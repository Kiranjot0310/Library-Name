//
//  AddBook.swift
//  LibraryProject
//
//  Created by Kiran Hans on 11/7/17.
//  Copyright © 2017 Kiran Hans. All rights reserved.
//

import Foundation
import UIKit

class Addbook: UIViewController , UITextFieldDelegate, UIPickerViewDataSource,UIPickerViewDelegate {
    var buttonClickId = 0
    
    @IBAction func addBtn(_ sender: UIButton) {
        if(bname.text!=="" || isbn.text!=="" || catButton.titleLabel?.text == "Select Book Category" ||  ravkButton.titleLabel?.text == "Select Rack Number"){
            
            let alert = UIAlertController(title: "Error Message", message: "All Fields are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }else{
            MyVariable.bookname.append(bname.text!)
            MyVariable.bookpublish.append(isbn.text!)
            MyVariable.bookcat.append((catButton.titleLabel?.text!)!)
            MyVariable.bookrack.append((ravkButton.titleLabel?.text!)!)
            
            
            let alert = UIAlertController(title: "Successful message", message: "Data Added", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
            
            bname.text=""
            isbn.text=""
            catButton.titleLabel?.text="Select Book Category"
            ravkButton.titleLabel?.text="Select Rack Number"
        }
        
        
    }
    @IBOutlet weak var ravkButton: UIButton!
    
    @IBAction func rackAction(_ sender: UIButton) {
        buttonClickId = 2;
        self.selectorUIView.isHidden = false;
        self.dropDown.isHidden = true;
        self.rackDrop.isHidden = false;
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    @IBAction func categoryAction(_ sender: UIButton) {
        buttonClickId = 1;
        self.selectorUIView.isHidden = false;
        self.dropDown.isHidden = false;
        self.rackDrop.isHidden = true;
    }
    @IBOutlet weak var catButton: UIButton!
    @IBAction func done(_ sender: UIButton) {
        if(buttonClickId == 1){
            if(catButton.titleLabel?.text == "Select Book Category"){
                let alert = UIAlertController(title: "Error Message", message: "Please Select Category ", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                return;
            }
        }else{
            if(ravkButton.titleLabel?.text == "Select Rack Number"){
                let alert = UIAlertController(title: "Error Message", message: "Please select Rack Number", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                return;
            }
        }
        self.selectorUIView.isHidden = true;
        
        
    }
    @IBOutlet weak var bname: UITextField!
    @IBOutlet weak var isbn: UITextField!
    
    
    @IBOutlet weak var rackDrop: UIPickerView!
    @IBOutlet weak var dropDown: UIPickerView!
    @IBOutlet weak var selectorUIView: UIView!
    var menu=MyVariable.category
    var gmenu = MyVariable.rack
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        
        if(pickerView==dropDown){
            return menu.count
        }else if(pickerView==rackDrop){
            return gmenu.count
        }
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if(pickerView==dropDown){
            return menu[row]
        }else if(pickerView==rackDrop){
            return gmenu[row]
        }
        return ""
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if(pickerView==dropDown){
            self.catButton.setTitle(menu[row], for: .normal);
        }else if(pickerView==rackDrop){
            self.ravkButton.setTitle(gmenu[row], for: .normal);
        }
        
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return true;
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.bname.delegate=self
        self.isbn.delegate=self
        
        
        
    }
    
    @IBAction func ADD(_ sender: UIButton) {
        let alert = UIAlertController(title: "", message: "Please Select Category ", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
        
    }
    
    
    @IBAction func RESET(_ sender: UIButton) {
        bname.text=""
        isbn.text=""
    }
    
}


