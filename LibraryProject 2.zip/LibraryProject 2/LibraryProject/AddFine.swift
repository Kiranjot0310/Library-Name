//
//  AddBorrower.swift
//  LibraryProject
//
//  Created by Kiran Hans on 11/7/17.
//  Copyright © 2017 Kiran Hans. All rights reserved.
//

import Foundation
import UIKit

class AddFine: UIViewController, UIPickerViewDataSource,UIPickerViewDelegate , UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
       
       self.view.endEditing(true)
        return true
    }
    @IBAction func doneAction(_ sender: UIButton) {
        if(self.userTypeButton.titleLabel?.text == "==Select User=="){
            let alert = UIAlertController(title: "Error Message", message: "Please select user type.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return;
        }
        self.selectorUIView.isHidden = true;
    }
    @IBAction func userTypeAction(_ sender: UIButton) {
         self.selectorUIView.isHidden = false;
    }
    @IBOutlet weak var userTypeButton: UIButton!
    @IBOutlet weak var selectorUIView: UIView!
    @IBAction func search(_ sender: UIButton) {
        var index=""
        let utype=self.userTypeButton.titleLabel?.text
        
        if(utype=="" || username.text!==""){
            let alert = UIAlertController(title: "Error Message", message: "All fields are required ", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
        }else{
            if(utype=="Faculty"){
                var fname=MyVariable.fid
                for i in 0..<fname.count{
                    if(fname[i]==username.text!){
                        index=String(i)
                    }
                }
            }else if(utype=="Student"){
                var fname=MyVariable.sid
                for i in 0..<fname.count{
                    if(fname[i]==username.text!){
                        index=String(i)
                    }
                }
            }
            if(index == ""){
                let alert = UIAlertController(title: "Sorry", message: "User does not exist", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
                uid.text!=""
            }else{
                var cindex=Int(index)
                if(utype=="Faculty"){
                    uid.text=MyVariable.fname[cindex!]
                }else if(utype=="Student"){
                    uid.text=MyVariable.sname[cindex!]
                }
            }
            
            
        }
    }
    @IBOutlet weak var amount: UITextField!
    @IBAction func add(_ sender: UIButton) {
        let utype=self.userTypeButton.titleLabel?.text
        
        if(utype=="" || username.text!=="" || uid.text!=="" || amount.text!==""){
            let alert = UIAlertController(title: "Error Message", message: "All fields are required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
        }else{
            var userid=[String]()
            var userstatus=""
            if(utype=="Faculty"){
                userid=MyVariable.fid
                userstatus="0"
            }else if(utype=="Student"){
                userid=MyVariable.sid
                userstatus="1"
            }
            
            let index = userid.index(of: username.text!)
          
            let useridInt=String(describing: index!)
            MyVariable.fine.append(amount.text!)
            MyVariable.finestatus.append("0")
            MyVariable.fineperson.append(useridInt)
            MyVariable.finepersontype.append(userstatus)
            let alert = UIAlertController(title: "Successful Message", message: "Data added", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            
            
        }
    }
    @IBOutlet weak var typedrop: UIPickerView!
   
    var typemenu=["Faculty","Student"]
    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var uid: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.uid.delegate=self
        self.username.delegate=self
        self.amount.delegate=self
        self.userTypeButton.layer.cornerRadius = 6.0;
        self.userTypeButton.layer.borderColor = UIColor.lightGray.cgColor;
        self.userTypeButton.layer.borderWidth = 0.5;


        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.hideKeyboardOnClick(_:)))
        self.view.addGestureRecognizer(tapGesture);
        
    }
    @objc func hideKeyboardOnClick(_ sender: UITapGestureRecognizer) {
        self.view.endEditing(true);
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        return typemenu.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return typemenu[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.view.endEditing(true);
        self.userTypeButton.setTitle(self.typemenu[row], for: .normal)
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        return true;
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        
    }
}
