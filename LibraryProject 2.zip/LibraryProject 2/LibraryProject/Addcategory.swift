//
//  Addcategory.swift
//  LibraryProject
//
//  Created by Kiran Hans on 11/7/17.
//  Copyright © 2017 Kiran Hans. All rights reserved.
//

import Foundation
import UIKit

class AddCategory: UIViewController,UITextFieldDelegate {
   
    @IBAction func add(_ sender: UIButton) {
        
        if(categoryname.text!==""){
            let alert = UIAlertController(title: "Erroe message", message: "Category field is required", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            MyVariable.category.append(categoryname.text!)
            let alert = UIAlertController(title: "Successful Message", message: "Data Added", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Done", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }
    
    }
    
    @IBAction func reset(_ sender: UIButton) {
        
        categoryname.text=""
    }
    @IBOutlet weak var categoryname: UITextField!
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        self.view.endEditing(true)
        return true
    }
    override func viewDidLoad() {
        print(MyVariable.category)
        super.viewDidLoad()
        self.categoryname.delegate=self
    }
}
