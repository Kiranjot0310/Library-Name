//
//  LibraryHome.swift
//  LibraryProject
//
//  Created by Kiran Hans on 11/7/17.
//  Copyright © 2017 Kiran Hans. All rights reserved.
//

import Foundation
import UIKit

class LibraryHome: UIViewController {
    @IBAction func logout(_ sender: UIButton) {
        let viewc:UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "viewc") as? ViewController)!
        self.navigationController?.pushViewController(viewc, animated: true)    }
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
        
    }
}
